create procedure go_to_version
(@numar int)
as
begin
declare @versiune_curenta int;
if @numar<0 or @numar>5
	RAISERROR('Versiunea nu exista!',11,1);
select top 1 @versiune_curenta = numar_versiune from Versiuni
while(@versiune_curenta <> @numar)
begin
	if (@versiune_curenta < @numar)
	begin
		if @versiune_curenta = 0
			exec v1;
		if @versiune_curenta = 1
			exec v2;
		else if @versiune_curenta = 2
			exec v3;
		else if @versiune_curenta = 3
			exec v4;
		else if @versiune_curenta = 4
			exec v5;
		set @versiune_curenta = @versiune_curenta + 1;
	end
	else 
	begin
		if @versiune_curenta = 5
			exec undo_v5;
		if @versiune_curenta = 4
			exec undo_v4;
		else if @versiune_curenta = 3
			exec undo_v3;
		else if @versiune_curenta = 2
			exec undo_v2;
		else if @versiune_curenta = 1
			exec undo_v1;
		set @versiune_curenta = @versiune_curenta - 1;
	end 
end
end;
go

