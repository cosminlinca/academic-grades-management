create procedure undo_v2
as
begin
alter table Turnee
drop constraint myConstraint
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 1 where cod_versiune = 1;
end
go

