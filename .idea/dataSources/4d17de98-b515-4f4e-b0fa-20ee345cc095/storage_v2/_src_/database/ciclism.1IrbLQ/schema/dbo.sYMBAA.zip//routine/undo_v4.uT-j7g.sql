create procedure undo_v4
as 
begin
alter table Tari
drop column cod_capitala
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 3 where cod_versiune = 1;
end
go

