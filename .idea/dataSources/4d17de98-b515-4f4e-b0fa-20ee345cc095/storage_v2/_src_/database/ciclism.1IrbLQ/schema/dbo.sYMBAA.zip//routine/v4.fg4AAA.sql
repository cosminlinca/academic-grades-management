create procedure v4
as
begin
alter table Tari
add cod_capitala INT
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 4 where cod_versiune = 1;
end
go

