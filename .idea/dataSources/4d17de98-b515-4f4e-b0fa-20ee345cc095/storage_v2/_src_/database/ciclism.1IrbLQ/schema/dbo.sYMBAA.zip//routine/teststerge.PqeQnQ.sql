
create procedure testSterge
@priority int
as
	begin
		declare @tabela NVARCHAR(100);
		select distinct @tabela=Name from Tables
			inner join TestTables on Tables.TableID = TestTables.TableID
			where TestTables.Position = @priority;
			
		if @tabela = 'Tari'
			delete from Tari where cod_tara>=10000;
		else if @tabela = 'Ciclisti' 
			delete from Ciclisti where id_ciclist>=10000;
		else if @tabela = 'CiclistiTurnee'
			delete from CiclistiTurnee where id_ciclist>=10000;
	end
go

