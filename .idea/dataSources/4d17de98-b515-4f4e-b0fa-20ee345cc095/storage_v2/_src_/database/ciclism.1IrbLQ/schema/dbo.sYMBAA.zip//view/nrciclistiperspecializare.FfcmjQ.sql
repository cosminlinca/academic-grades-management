create view NrCiclistiPerSpecializare
as
	select S.tip_sp, count(S.tip_sp) as nr from Specializari S
	inner join CiclistiSpecializari CS on
	CS.cod_sp = s.cod_sp
	inner join Ciclisti C on
	C.id_ciclist = CS.id_ciclist
	group by S.tip_sp
go

