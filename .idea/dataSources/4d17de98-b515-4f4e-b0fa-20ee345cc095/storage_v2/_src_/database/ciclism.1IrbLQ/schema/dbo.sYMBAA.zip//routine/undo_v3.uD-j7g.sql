create procedure undo_v3
as
begin
drop table Capitale
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 2 where cod_versiune = 1;
end
go

