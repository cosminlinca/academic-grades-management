create procedure v5
as
begin
alter table Tari
add constraint fk_capitala2
foreign key (cod_capitala) references Capitale(id_capitala)
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 5 where cod_versiune = 1;
end
go

