create procedure mainTest
@nume VARCHAR(50)
as
	begin
		--crearea unui nou test--
		declare @testid int;
		insert into TestRuns(Description) 
			values(@nume);
		select top 1 @testid=TestRunID from TestRuns where Description=@nume;

		--start time (time1) --
		declare @time datetime;
		declare @time1 datetime;
		declare @time2 datetime;
		set @time = getdate();

		--adaugarea in ordinea inversa data de Position--
		declare @priority int
		select @priority = max(Position) from TestTables where TestID = 1;

		--testarea adaugarii--
		while @priority > 0
			begin
				print @priority;
				declare @tabela nvarchar(100);
				select distinct @tabela = Name from Tables
					inner join TestTables on Tables.TableID = TestTables.TableID
					where TestTables.Position = @priority;
				declare @nrRow int;
				select top 1 @nrRow = NoOfRows from TestTables
					inner join Tables on TestTables.TableID = Tables.TableID and Tables.Name = @tabela

				set @time1 = getdate();
				exec testAdauga @nrRow, @tabela;
				set @time2 = getdate();

				insert into TestRunTables(TestRunID, TableID, StartAt, EndAt) values
					(@testid, @priority, @time1, @time2)

				set @priority = @priority - 1;
			end

		
		declare @k int;
		set @k = 1;
		select @priority = count(*) from Views;

		while @k <= @priority
			begin
				declare @view varchar(50);
				select @view = Name from Views where ViewID = @k;
				declare @q_exec varchar(100);
				set @q_exec = concat('select * from ', @view);

				--exec select on view--
				set @time1 = getdate(); 
				exec(@q_exec);
				set @time2 = getdate();

				insert into TestRunViews(TestRunID, ViewID, StartAt, EndAt) values
				(@testid, @k, @time1, @time2)

				set @k = @k + 1;
			end


		--testarea stergerii--
		set @priority = 1;
		while @priority <= 3
			begin
				set @time1 = getdate();
				exec testSterge @priority;
				set @time2 = getdate();
				set @priority = @priority + 1;
			end

		--final time (time 2) -> start time for views--
		--declare @time2 datetime;
		--set @time2 = getdate();

		
		
		--final time for views (time3)--
		declare @time3 datetime;
		set @time3 = getdate();

		--update start/final time for test runs
		update TestRuns
		set StartAt = @time, EndAt = @time3
		where TestRunID = @testid

	end
go

