create procedure testAdauga
@nrRow int,
@tabela varchar(100)
as
	begin
		declare @id int;
		set @id = 10000;
		if @tabela = 'Tari'
			while @id < 10000 + @nrRow
				begin
					insert into Tari(cod_tara, nume) values
						(@id, concat('Ro', convert(varchar(4),@id)));
					set @id = @id+1;
				end
		else if @tabela = 'Ciclisti'
			while @id < 10000 + @nrRow
				begin
					insert into Ciclisti(id_ciclist, nume, cod_tara, cod_echipa, data_nasterii) values
						(@id, concat('Sagan', convert(varchar(4),@id)), 1001, 2001, '1980-7-14');
					set @id = @id+1;
				end
		else if @tabela = 'CiclistiTurnee'
			while @id < 10000 + @nrRow
				begin
					insert into CiclistiTurnee(id_ciclist, cod_turneu, loc_obtinut) values
						(@id, 4001, 5);
					set @id = @id+1;
				end
		end
go

