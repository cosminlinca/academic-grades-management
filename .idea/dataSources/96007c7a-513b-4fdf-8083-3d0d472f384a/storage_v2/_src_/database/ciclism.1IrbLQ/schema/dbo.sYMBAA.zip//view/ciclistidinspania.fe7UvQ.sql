create view CiclistiDinSpania
as
	select C.nume from Ciclisti C 
	inner join Tari T on
	T.cod_tara = C.cod_tara
	where T.nume = 'Spania'
go

