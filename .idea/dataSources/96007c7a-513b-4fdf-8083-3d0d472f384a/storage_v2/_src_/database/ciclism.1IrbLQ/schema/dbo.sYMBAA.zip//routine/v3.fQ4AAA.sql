create procedure v3
as
begin
create table Capitale(
	id_capitala INT NOT NULL PRIMARY KEY,
	nume VARCHAR(30),
	nr_locuitori INT,
	nr_centre_recrutare INT,
);
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 3 where cod_versiune = 1;
end
go

