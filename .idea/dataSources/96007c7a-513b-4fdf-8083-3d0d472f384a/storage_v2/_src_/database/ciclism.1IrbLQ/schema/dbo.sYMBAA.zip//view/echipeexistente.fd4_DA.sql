create view EchipeExistente
as
	select denumire, nr_ciclisti from Echipe
go

