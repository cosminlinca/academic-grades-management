create procedure v2
as
begin
alter table Turnee
add constraint myConstraint default 'no name' for denumire
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 2 where cod_versiune = 1;
end
go

