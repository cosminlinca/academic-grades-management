create procedure v1
as
begin
alter table Sponsori
alter column capital FLOAT;
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 1 where cod_versiune = 1;
end

go

