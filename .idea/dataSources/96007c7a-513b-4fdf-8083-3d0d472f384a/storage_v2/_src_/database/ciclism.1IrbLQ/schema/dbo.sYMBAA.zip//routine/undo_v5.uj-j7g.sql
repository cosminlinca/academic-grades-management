create procedure undo_v5
as
begin
alter table Tari
drop constraint fk_capitala2
if(@@ERROR = 0)
	update Versiuni set numar_versiune = 4 where cod_versiune = 1;
end
go

